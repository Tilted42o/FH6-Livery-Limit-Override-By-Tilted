package main

import (
	"bytes"
	"errors"
	"fmt"
	"os"
	"sort"
)

type patchState string

const (
	stateOriginal    patchState = "not installed"
	stateUpgrade     patchState = "sticker-only update available"
	stateLegacyBeta5 patchState = "beta5 decal-cap update available"
	stateCurrent     patchState = "up to date"
)

type updatePlan struct {
	State       patchState
	CurrentSHA  string
	Full        profile
	Upgrade     profile
	LegacyBeta5 profile
	Surface     profile
	Detector    string
	Diag        diagnostics
}

func inspectUpdate(b []byte, extra []namedProfile) (updatePlan, error) {
	r := updatePlan{CurrentSHA: digest(b), Diag: diagnostics{SHA256: digest(b), FileBytes: len(b)}}
	g, err := detectVinylReader(b)
	if err != nil {
		r.Diag.VinylReader = err.Error()
		r.Diag.Reason = "Decal/vinyl compatibility could not be verified: " + err.Error()
		return r, compatibilityError(r.Diag)
	}

	// Normalize only the independently verified reader immediate to the stock
	// 3,000 value so the existing surface detector can identify the underlying
	// build regardless of whether it is stock, beta4, beta5, or this release.
	normal := bytes.Clone(b)
	copy(normal[g.Offset:], u32bytes(vinylOriginalLimit))
	s, err := detect(normal, extra)
	r.Diag = s.Diag
	r.Diag.SHA256 = r.CurrentSHA
	r.Diag.VinylReader = fmt.Sprintf("full function and PE runtime entry verified; current decal/vinyl cap %d", g.Value)
	if err != nil {
		return r, compatibilityError(r.Diag)
	}
	if g.Value != vinylOriginalLimit && !s.Restore {
		r.Diag.Reason = "Only the decal/vinyl reader is overridden. This is not a supported installation state."
		return r, compatibilityError(r.Diag)
	}

	original := bytes.Clone(normal)
	if s.Restore {
		for _, e := range s.Profile.Edits {
			if e.Offset < 0 || len(e.After) == 0 || e.Offset > len(original)-len(e.After) || len(e.Before) != len(e.After) || !bytes.Equal(original[e.Offset:e.Offset+len(e.After)], e.After) {
				return r, errors.New("Existing sticker/surface patch bytes do not match; no file was changed.")
			}
			copy(original[e.Offset:], e.Before)
		}
	}
	if digest(original) != s.Profile.Original {
		return r, errors.New("Original build could not be reconstructed for validation; no file was changed.")
	}

	surfaceBytes, err := transform(original, s.Profile)
	if err != nil {
		return r, err
	}

	stableEdit := vinylEdit(g.Offset, vinylOriginalLimit, vinylReleaseLimit)
	beta5ToStable := vinylEdit(g.Offset, vinylBeta5Limit, vinylReleaseLimit)
	beta5Edit := vinylEdit(g.Offset, vinylOriginalLimit, vinylBeta5Limit)

	edits := append([]edit{}, s.Profile.Edits...)
	edits = append(edits, stableEdit)
	sort.Slice(edits, func(i, j int) bool { return edits[i].Offset < edits[j].Offset })
	for i, e := range edits {
		if i > 0 && edits[i-1].Offset+len(edits[i-1].After) > e.Offset {
			return r, errors.New("Overlapping patch plans were rejected.")
		}
	}

	stableBytes := bytes.Clone(surfaceBytes)
	if !bytes.Equal(stableBytes[stableEdit.Offset:stableEdit.Offset+4], stableEdit.Before) {
		return r, errors.New("Sticker/surface profile changes the decal/vinyl reader; stopped.")
	}
	copy(stableBytes[stableEdit.Offset:], stableEdit.After)

	beta5Bytes := bytes.Clone(surfaceBytes)
	if !bytes.Equal(beta5Bytes[beta5Edit.Offset:beta5Edit.Offset+4], beta5Edit.Before) {
		return r, errors.New("Sticker/surface profile changes the decal/vinyl reader; stopped.")
	}
	copy(beta5Bytes[beta5Edit.Offset:], beta5Edit.After)

	r.Full = profile{Original: s.Profile.Original, Patched: digest(stableBytes), Edits: edits}
	r.Upgrade = profile{Original: s.Profile.Patched, Patched: r.Full.Patched, Edits: []edit{stableEdit}}
	r.LegacyBeta5 = profile{Original: digest(beta5Bytes), Patched: r.Full.Patched, Edits: []edit{beta5ToStable}}
	r.Surface = s.Profile
	r.Detector = s.Detector

	switch r.CurrentSHA {
	case r.Full.Original:
		r.State = stateOriginal
	case r.Upgrade.Original:
		r.State = stateUpgrade
	case r.LegacyBeta5.Original:
		r.State = stateLegacyBeta5
	case r.Full.Patched:
		r.State = stateCurrent
	default:
		return r, errors.New("Executable does not match a complete supported patch state; no file was changed.")
	}
	r.Diag.PatchState = string(r.State)
	return r, nil
}

// The original, full-file verified backup is mandatory for an update. Never
// invent an original backup by undoing a patch in an otherwise unknown file.
func applyUpdate(path string, p updatePlan) (bool, error) {
	unlock, err := lockExecutable(path)
	if err != nil {
		return false, err
	}
	defer unlock()
	current, err := readRegularFile(path)
	if err != nil {
		return false, err
	}
	if digest(current) != p.CurrentSHA {
		return false, errors.New("The executable changed after detection. No file was changed.")
	}
	if p.State == stateCurrent {
		return false, nil
	}

	var original, out []byte
	var recoveryProfile *profile
	switch p.State {
	case stateOriginal:
		original = current
		out, err = transform(original, p.Full)
	case stateUpgrade:
		original, _, err = readVerifiedBackup(path, p.Full)
		if err != nil {
			return false, fmt.Errorf("Update stopped: %w Keep or restore the original backup from your sticker-only patch.", err)
		}
		out, err = transform(current, p.Upgrade)
		recoveryProfile = &p.Upgrade
	case stateLegacyBeta5:
		original, _, err = readVerifiedBackup(path, p.Full)
		if err != nil {
			return false, fmt.Errorf("Update stopped: %w Keep or restore the original backup from beta5.", err)
		}
		out, err = transform(current, p.LegacyBeta5)
		recoveryProfile = &p.LegacyBeta5
	default:
		return false, errors.New("Unknown update state; stopped.")
	}
	if err != nil {
		return false, err
	}

	if p.State != stateOriginal {
		expected, e := transform(original, p.Full)
		if e != nil {
			return false, e
		}
		if !bytes.Equal(expected, out) {
			return false, errors.New("Update output does not match a fresh installation from the verified original.")
		}
	}

	if err = backup(path, original, p.Full); err != nil {
		return false, err
	}
	if recoveryProfile != nil {
		// Keep the previous patched executable as an additional recovery copy.
		if err = backup(path, current, *recoveryProfile); err != nil {
			return false, err
		}
	}
	if err = commitVerified(path, p.CurrentSHA, out); err != nil {
		return false, err
	}
	return true, nil
}

func restoreUpdate(path string, p updatePlan) error {
	if p.State != stateUpgrade && p.State != stateLegacyBeta5 && p.State != stateCurrent {
		return errors.New("No installed override to restore.")
	}
	rp := p.Full
	rp.Patched = p.CurrentSHA
	return install(path, rp, true)
}

func readRegularFile(path string) ([]byte, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return nil, err
	}
	if !info.Mode().IsRegular() {
		return nil, errors.New("Select a regular executable file; links and folders are not accepted.")
	}
	return os.ReadFile(path)
}
