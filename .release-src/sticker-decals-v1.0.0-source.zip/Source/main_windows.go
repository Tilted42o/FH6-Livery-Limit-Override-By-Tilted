//go:build windows

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

var user32 = syscall.NewLazyDLL("user32.dll")
var dialog = syscall.NewLazyDLL("comdlg32.dll")
var kernel32 = syscall.NewLazyDLL("kernel32.dll")
var shell32 = syscall.NewLazyDLL("shell32.dll")

const appTitle = "Layer Limit Override - Sticker + Decal Edition"

func w(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func message(s string, flags uintptr) uintptr {
	r, _, _ := user32.NewProc("MessageBoxW").Call(0, uintptr(unsafe.Pointer(w(s))), uintptr(unsafe.Pointer(w(appTitle))), flags)
	return r
}

type openFileName struct {
	Size            uint32
	Owner           uintptr
	Instance        uintptr
	Filter          *uint16
	CustomFilter    *uint16
	MaxCustomFilter uint32
	FilterIndex     uint32
	File            *uint16
	MaxFile         uint32
	FileTitle       *uint16
	MaxFileTitle    uint32
	InitialDir      *uint16
	Title           *uint16
	Flags           uint32
	FileOffset      uint16
	FileExtension   uint16
	DefaultExt      *uint16
	CustomData      uintptr
	Hook            uintptr
	TemplateName    *uint16
	Reserved        uintptr
	Reserved2       uint32
	FlagsEx         uint32
}

func choose() (string, error) {
	buf := make([]uint16, 32768)
	filter := syscall.StringToUTF16("Game executable (*.exe)")
	filter = append(filter, syscall.StringToUTF16("*.exe")...)
	filter = append(filter, 0)
	o := openFileName{Filter: &filter[0], File: &buf[0], MaxFile: uint32(len(buf)), Title: w("Select your installed Forza Horizon 6 executable"), Flags: 0x1000 | 0x800 | 0x80000 | 0x8}
	o.Size = uint32(unsafe.Sizeof(o))
	ret, _, _ := dialog.NewProc("GetOpenFileNameW").Call(uintptr(unsafe.Pointer(&o)))
	if ret == 0 {
		code, _, _ := dialog.NewProc("CommDlgExtendedError").Call()
		if code != 0 {
			return "", syscall.Errno(code)
		}
		return "", nil
	}
	return syscall.UTF16ToString(buf), nil
}

func openURL(url string) error {
	r, _, e := shell32.NewProc("ShellExecuteW").Call(
		0,
		uintptr(unsafe.Pointer(w("open"))),
		uintptr(unsafe.Pointer(w(url))),
		0, 0, 1,
	)
	if r <= 32 {
		if e != nil && e != syscall.Errno(0) {
			return e
		}
		return fmt.Errorf("Windows could not open the DVS project page (ShellExecute code %d)", r)
	}
	return nil
}

func showDVSPrerequisite(buildName, sha string) {
	msg := fmt.Sprintf(`MISSING OFFLINE PATCH

Your FH6 executable needs the offline patch before Layer Limit Override can be applied.

1. Close Forza Horizon 6.
2. Download and apply the DVS FH6 Offline Patcher from:

%s

3. After the offline patch has been applied properly, run Layer Limit Override again and select your patched forzahorizon6.exe.

Shoutout and credit to DVS for the FH6 Offline Patcher.

Open the DVS download page now?`, dvsProjectURL)
	if message(msg, 0x24) == 6 {
		if err := openURL(dvsProjectURL); err != nil {
			message(err.Error()+"\n\nCopy and paste this address into your browser:\n"+dvsProjectURL, 0x10)
		}
	}
}

func replaceFile(from, to string) error {
	ok, _, e := kernel32.NewProc("MoveFileExW").Call(uintptr(unsafe.Pointer(w(from))), uintptr(unsafe.Pointer(w(to))), 0x1|0x8)
	if ok == 0 {
		return e
	}
	return nil
}

func lockExecutable(path string) (func(), error) {
	// Windows mutex ownership belongs to an OS thread, not a Go goroutine.
	runtime.LockOSThread()
	abs, err := filepath.Abs(path)
	if err != nil {
		runtime.UnlockOSThread()
		return nil, err
	}
	if resolved, e := filepath.EvalSymlinks(abs); e == nil {
		abs = resolved
	}
	name := "Local\\LayerLimitOverride-" + digest([]byte(strings.ToLower(filepath.Clean(abs))))
	h, _, e := kernel32.NewProc("CreateMutexW").Call(0, 0, uintptr(unsafe.Pointer(w(name))))
	if h == 0 {
		runtime.UnlockOSThread()
		return nil, fmt.Errorf("Could not lock this patch operation: %v", e)
	}
	closeHandle := func() { kernel32.NewProc("CloseHandle").Call(h) }
	result, _, _ := kernel32.NewProc("WaitForSingleObject").Call(h, 0)
	if result != 0 && result != 0x80 {
		closeHandle()
		runtime.UnlockOSThread()
		return nil, fmt.Errorf("Another Layer Limit Override operation is using this executable. Close it and try again.")
	}
	return func() { kernel32.NewProc("ReleaseMutex").Call(h); closeHandle(); runtime.UnlockOSThread() }, nil
}

func performanceWarning() string {
	return `PERFORMANCE WARNING

Decals/vinyl groups above Forza's original 3,000-layer limit can lower frame rates while you are inside the livery editor and can make saving take longer.

Based on testing so far, this appears to affect the editor only and has shown no noticeable performance impact after leaving the editor and returning to normal driving/gameplay.`
}

func main() {
	var path string
	var err error
	if len(os.Args) > 1 {
		path = os.Args[1]
	} else {
		path, err = choose()
	}
	if err != nil {
		message(err.Error(), 0x10)
		return
	}
	if path == "" {
		return
	}

	b, err := os.ReadFile(path)
	if err != nil {
		message(err.Error(), 0x10)
		return
	}

	sha := digest(b)
	if buildName, ok := protectedBuildName(sha); ok {
		showDVSPrerequisite(buildName, sha)
		return
	}

	extra, warning := loadExternalProfiles()
	if warning != "" {
		message(warning+"\n\nBuilt-in and semantic detection will still be available.", 0x30)
	}

	r, err := inspectUpdate(b, extra)
	if err != nil {
		// An unsupported decal/vinyl reader must not remove the user's ability to
		// restore a recognized sticker-only installation.
		if old, e := detect(b, extra); e == nil && old.Restore {
			if message("Your existing sticker/surface override was recognized, but this build's decal/vinyl loading code could not be verified. No file was changed.\n\nWould you like to RESTORE the original executable from its verified backup?\nChoose No to keep the existing override.", 0x134) == 6 {
				if e = install(path, old.Profile, true); e != nil {
					message(e.Error(), 0x10)
				} else {
					message("Original executable restored and verified. Your backup was retained.", 0x40)
				}
				return
			}
		}
		message(err.Error(), 0x10)
		if message("Create a small compatibility report for this build?\n\nIt contains hashes, PE metadata, detector counts and a few tiny candidate code windows — never your whole game executable.", 0x24) == 6 {
			report, reportErr := createCompatibilityReport(path, r.Diag)
			if reportErr != nil {
				message("Could not create the compatibility report:\n\n"+reportErr.Error(), 0x10)
			} else {
				message("Compatibility report created:\n\n"+report+"\n\nSend this file with your FH6 version/storefront.", 0x40)
			}
		}
		return
	}

	restore := false
	switch r.State {
	case stateOriginal:
		prompt := fmt.Sprintf(`Layer Limit Override - Sticker + Decal Edition v1.0.0
By Tilted42o

Close Forza before continuing.

This edition applies:
• Left / Right / Top sticker layers: 30,000 each
• Other supported sticker surfaces: 10,000 each
• Saved decal/vinyl group limit: 6,500 direct child entries

%s

A verified original backup will be kept at:
%s

Apply the Sticker + Decal Edition now?`, performanceWarning(), buildBackupPath(path, r.Full))
		if message(prompt, 0x31) != 1 {
			return
		}
	case stateUpgrade:
		choice := message("STICKER-ONLY VERSION DETECTED\n\nYour existing sticker override is recognized.\n\nYES: add the 6,500 decal/vinyl limit and keep the existing sticker limits.\nNO: restore your verified original executable.\nCANCEL: leave everything as it is.\n\n"+performanceWarning(), 0x33)
		if choice == 2 {
			return
		}
		if choice != 6 && choice != 7 {
			return
		}
		restore = choice == 7
	case stateLegacyBeta5:
		choice := message("BETA5 TEST VERSION DETECTED\n\nThe experimental 30,000 decal/vinyl cap is installed.\n\nThe release edition locks that decal/vinyl limit to 6,500 for better editor stability.\n\nYES: update beta5 to the 6,500 release cap.\nNO: restore your verified original executable.\nCANCEL: leave beta5 installed.\n\n"+performanceWarning(), 0x33)
		if choice == 2 {
			return
		}
		if choice != 6 && choice != 7 {
			return
		}
		restore = choice == 7
	case stateCurrent:
		if message("Sticker + Decal Edition is already installed and up to date.\n\nSticker limits: 30,000 / 10,000\nDecal/vinyl group limit: 6,500\n\nNothing will be applied again.\n\nWould you like to RESTORE the original executable instead?\nClose Forza first. Designs above the original limits may no longer load after restoration.", 0x144) != 6 {
			return
		}
		restore = true
	default:
		message("Unrecognized patch state. No file was changed.", 0x10)
		return
	}

	if restore {
		err = restoreUpdate(path, r)
	} else {
		_, err = applyUpdate(path, r)
	}
	if err != nil {
		message(err.Error(), 0x10)
		return
	}
	if restore {
		message("Original executable restored and verified.\n\nThe build-specific backup was retained.", 0x40)
	} else {
		message("Sticker + Decal Edition installed and verified.\n\nSticker limits: 30,000 / 10,000\nDecal/vinyl group limit: 6,500\n\nRemember: very large decals can lower editor FPS and take longer to save. Testing so far shows no noticeable performance impact outside the editor.\n\nRun this tool again to verify the install or restore the original.", 0x40)
	}
}
