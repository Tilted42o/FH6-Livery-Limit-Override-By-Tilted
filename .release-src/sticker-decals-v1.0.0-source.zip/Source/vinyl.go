package main

import (
	"bytes"
	"debug/pe"
	"encoding/binary"
	"fmt"
)

// The decal/vinyl-group reader is separate from the normal surface limits.
// The whole reviewed function must match, except for the one limit immediate.
// A coincidental numeric constant or a changed function is never sufficient.
const vinylFunctionSize = 0x782
const vinylImmediate = 0x1b5
const vinylFunctionDigest = "a3bb90052b29e716e78b0f067180d42feefa3db575df6118804eb45964602e0c"

const (
	vinylOriginalLimit = uint32(3000)
	vinylReleaseLimit  = uint32(6500)
	vinylBeta5Limit    = uint32(30000)
)

var vinylAnchor = unhex("48895c24085556574154415541564157488d6c24d94881eca0000000488bfa48")

type vinylMatch struct {
	Offset int
	Value  uint32
}

func u32bytes(v uint32) []byte {
	b := make([]byte, 4)
	binary.LittleEndian.PutUint32(b, v)
	return b
}

func vinylEdit(offset int, before, after uint32) edit {
	return edit{Offset: offset, Before: u32bytes(before), After: u32bytes(after)}
}

func detectVinylReader(b []byte) (vinylMatch, error) {
	f, err := pe.NewFile(bytes.NewReader(b))
	if err != nil {
		return vinylMatch{}, fmt.Errorf("invalid PE file: %w", err)
	}
	defer f.Close()
	if f.Machine != pe.IMAGE_FILE_MACHINE_AMD64 {
		return vinylMatch{}, fmt.Errorf("expected Windows x64")
	}
	oh, ok := f.OptionalHeader.(*pe.OptionalHeader64)
	if !ok {
		return vinylMatch{}, fmt.Errorf("missing PE32+ header")
	}
	var found []vinylMatch
	for _, s := range f.Sections {
		if s.Characteristics&0x20000000 == 0 {
			continue
		}
		start, end := uint64(s.Offset), uint64(s.Offset)+uint64(s.Size)
		if end > uint64(len(b)) {
			return vinylMatch{}, fmt.Errorf("truncated executable section")
		}
		code := b[int(start):int(end)]
		for pos := 0; pos < len(code); {
			n := bytes.Index(code[pos:], vinylAnchor)
			if n < 0 {
				break
			}
			at := pos + n
			pos = at + len(vinylAnchor)
			if at > len(code)-vinylFunctionSize {
				continue
			}
			body := bytes.Clone(code[at : at+vinylFunctionSize])
			value := binary.LittleEndian.Uint32(body[vinylImmediate:])
			clear(body[vinylImmediate : vinylImmediate+4])
			if digest(body) != vinylFunctionDigest {
				continue
			}
			switch value {
			case vinylOriginalLimit, vinylReleaseLimit, vinylBeta5Limit:
				// Supported states: stock, current release, and beta5 test cap.
			default:
				return vinylMatch{}, fmt.Errorf("decal/vinyl reader has an unrecognized or partial override (%d)", value)
			}
			rva := uint64(s.VirtualAddress) + uint64(at)
			if rva+vinylFunctionSize > 0xffffffff || !runtimeFunctionMatches(b, f, oh, uint32(rva), uint32(rva+vinylFunctionSize)) {
				return vinylMatch{}, fmt.Errorf("decal/vinyl reader function boundaries could not be verified")
			}
			found = append(found, vinylMatch{Offset: int(start) + at + vinylImmediate, Value: value})
		}
	}
	if len(found) != 1 {
		return vinylMatch{}, fmt.Errorf("found %d verified decal/vinyl readers; expected exactly one", len(found))
	}
	return found[0], nil
}

func runtimeFunctionMatches(b []byte, f *pe.File, oh *pe.OptionalHeader64, begin, end uint32) bool {
	if oh.NumberOfRvaAndSizes <= 3 {
		return false
	}
	d := oh.DataDirectory[3]
	if d.Size == 0 || d.Size%12 != 0 {
		return false
	}
	for _, s := range f.Sections {
		if uint64(d.VirtualAddress) < uint64(s.VirtualAddress) || uint64(d.VirtualAddress)+uint64(d.Size) > uint64(s.VirtualAddress)+uint64(s.Size) {
			continue
		}
		start := uint64(s.Offset) + uint64(d.VirtualAddress) - uint64(s.VirtualAddress)
		if start+uint64(d.Size) > uint64(len(b)) {
			return false
		}
		count := 0
		for at := start; at < start+uint64(d.Size); at += 12 {
			x, y := binary.LittleEndian.Uint32(b[at:]), binary.LittleEndian.Uint32(b[at+4:])
			if x < end && y > begin {
				if x != begin || y != end {
					return false
				}
				count++
			}
		}
		return count == 1
	}
	return false
}
