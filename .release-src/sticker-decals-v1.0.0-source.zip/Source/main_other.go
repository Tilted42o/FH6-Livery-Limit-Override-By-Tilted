//go:build !windows

package main

import (
	"fmt"
	"os"
)

// Test host lock. The Windows release uses an OS mutex that is released even
// after an interrupted process; it does not leave a lock file behind.
func lockExecutable(path string) (func(), error) {
	name := path + ".lu-layers-lock"
	f, err := os.OpenFile(name, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return nil, fmt.Errorf("Another patch operation may be using this executable: %w", err)
	}
	return func() { f.Close(); os.Remove(name) }, nil
}

func replaceFile(from, to string) error { return os.Rename(from, to) }
func main()                             {}
