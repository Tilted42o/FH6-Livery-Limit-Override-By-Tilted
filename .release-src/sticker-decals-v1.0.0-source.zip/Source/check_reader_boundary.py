"""Run only the reviewed 18-byte compare/branch in an isolated native harness.

Linux x86-64 test host only. Does not launch or write the game executable.
This checks the threshold, not complete vinyl loading or game compatibility.
Usage: python check_reader_boundary.py path/to/reference/forzahorizon6.exe
"""
import ctypes
import hashlib
import json
import mmap
import platform
import struct
import sys
from pathlib import Path

if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
    raise SystemExit("This test requires a Linux x86-64 host.")
data = Path(sys.argv[1]).read_bytes()
if hashlib.sha256(data).hexdigest() != "1bd6e4260c71d394b8ce42bac188c200eaeb8a88a6c8e1d2dca0aa3f6965661d":
    raise SystemExit("Reference fixture hash differs; nothing executed.")
original = data[0x48ff354:0x48ff366]
assert original == bytes.fromhex("b9b80b00000fb745c3663bc10f876e020000")
counts = [0, 2999, 3000, 3001, 6499, 6500, 6501, 10000, 30000, 32767, 65535]
results = []
for cap in (3000, 6500):
    code = bytearray(original)
    code[1:5] = struct.pack("<I", cap)
    # Preserve the caller's RBP and point [RBP-0x3d] at the supplied uint16.
    prefix = bytes.fromhex("55488d6f3d")
    block = bytearray(b"\xcc" * 4096)
    block[:len(prefix)] = prefix
    block[len(prefix):len(prefix)+len(code)] = code
    # The original unsigned JA target is 0x280 bytes from the compare block.
    accept = len(prefix) + len(code)
    block[accept:accept+7] = bytes.fromhex("b8010000005dc3")
    reject = len(prefix) + 0x280
    block[reject:reject+4] = bytes.fromhex("31c05dc3")
    region = mmap.mmap(-1, 4096, prot=mmap.PROT_READ | mmap.PROT_WRITE | mmap.PROT_EXEC)
    region.write(block)
    address = ctypes.addressof(ctypes.c_char.from_buffer(region))
    fn = ctypes.CFUNCTYPE(ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint16))(address)
    for count in counts:
        value = ctypes.c_uint16(count)
        accepted = bool(fn(ctypes.byref(value)))
        assert accepted == (count <= cap), (cap, count, accepted)
        results.append({"limit": cap, "count": count, "accepted": accepted})
    del fn
    region.close()
print(json.dumps({"test": "extracted group-reader unsigned comparison", "passed": len(results), "results": results}, indent=2))
