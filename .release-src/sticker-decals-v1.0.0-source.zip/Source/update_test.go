package main

import (
	"bytes"
	"debug/pe"
	"os"
	"path/filepath"
	"testing"
)

func updateFixture() ([]byte, []byte, []byte, updatePlan) {
	original := []byte("HEAD-OLD-GRP3-TAIL")
	older := []byte("HEAD-NEW-GRP3-TAIL")
	latest := []byte("HEAD-NEW-GRPX-TAIL")
	surface := edit{5, []byte("OLD"), []byte("NEW")}
	group := edit{12, []byte("3"), []byte("X")}
	p := updatePlan{State: stateOriginal, CurrentSHA: digest(original),
		Full:    profile{digest(original), digest(latest), []edit{surface, group}},
		Upgrade: profile{digest(older), digest(latest), []edit{group}},
		Surface: profile{digest(original), digest(older), []edit{surface}}}
	return original, older, latest, p
}

func mustWrite(t *testing.T, path string, b []byte) {
	t.Helper()
	if err := os.WriteFile(path, b, 0600); err != nil {
		t.Fatal(err)
	}
}
func assertFile(t *testing.T, path string, want []byte) {
	t.Helper()
	got, err := os.ReadFile(path)
	if err != nil || !bytes.Equal(got, want) {
		t.Fatalf("file %s mismatch: %v", path, err)
	}
}

func TestUpdateLifecycle(t *testing.T) {
	for _, mode := range []string{"fresh", "upgrade", "legacy-backup"} {
		t.Run(mode, func(t *testing.T) {
			o, old, latest, p := updateFixture()
			path := filepath.Join(t.TempDir(), "game.exe")
			mustWrite(t, path, o)
			if mode != "fresh" {
				if err := install(path, p.Surface, false); err != nil {
					t.Fatal(err)
				}
				if mode == "legacy-backup" {
					if err := os.Rename(buildBackupPath(path, p.Full), legacyBackupPath(path)); err != nil {
						t.Fatal(err)
					}
				}
				p.State = stateUpgrade
				p.CurrentSHA = digest(old)
			}
			changed, err := applyUpdate(path, p)
			if err != nil || !changed {
				t.Fatalf("update: %v %v", changed, err)
			}
			assertFile(t, path, latest)
			assertFile(t, buildBackupPath(path, p.Full), o)
			if mode != "fresh" {
				assertFile(t, buildBackupPath(path, p.Upgrade), old)
			}
			info, _ := os.Stat(path)
			p.State = stateCurrent
			p.CurrentSHA = digest(latest)
			changed, err = applyUpdate(path, p)
			if err != nil || changed {
				t.Fatalf("repeat: %v %v", changed, err)
			}
			now, _ := os.Stat(path)
			if !info.ModTime().Equal(now.ModTime()) {
				t.Fatal("repeat rewrote executable")
			}
			if err = restoreUpdate(path, p); err != nil {
				t.Fatal(err)
			}
			assertFile(t, path, o)
			assertFile(t, buildBackupPath(path, p.Full), o)
		})
	}
}

func TestUnsafeUpdatesLeaveExecutableUnchanged(t *testing.T) {
	for _, mode := range []string{"missing-backup", "wrong-backup", "wrong-recovery-copy", "stale-plan", "bad-upgrade-bytes", "bad-target-hash", "concurrent"} {
		t.Run(mode, func(t *testing.T) {
			o, old, _, p := updateFixture()
			path := filepath.Join(t.TempDir(), "game.exe")
			mustWrite(t, path, old)
			p.State = stateUpgrade
			p.CurrentSHA = digest(old)
			if mode != "missing-backup" {
				mustWrite(t, buildBackupPath(path, p.Full), o)
			}
			if mode == "wrong-backup" {
				mustWrite(t, buildBackupPath(path, p.Full), []byte("another game build"))
			}
			if mode == "wrong-recovery-copy" {
				mustWrite(t, buildBackupPath(path, p.Upgrade), []byte("do not overwrite"))
			}
			if mode == "stale-plan" {
				p.CurrentSHA = digest(o)
			}
			if mode == "bad-upgrade-bytes" {
				p.Upgrade.Edits[0].Before = []byte("?")
			}
			if mode == "bad-target-hash" {
				p.Upgrade.Patched = digest(o)
			}
			if mode == "concurrent" {
				unlock, err := lockExecutable(path)
				if err != nil {
					t.Fatal(err)
				}
				defer unlock()
			}
			changed, err := applyUpdate(path, p)
			if err == nil || changed {
				t.Fatalf("accepted %s", mode)
			}
			assertFile(t, path, old)
			if mode == "wrong-recovery-copy" {
				assertFile(t, buildBackupPath(path, p.Upgrade), []byte("do not overwrite"))
			}
			if mode == "wrong-backup" {
				assertFile(t, buildBackupPath(path, p.Full), []byte("another game build"))
			}
		})
	}
}

func TestRestoreOlderInstallation(t *testing.T) {
	o, old, _, p := updateFixture()
	path := filepath.Join(t.TempDir(), "game.exe")
	mustWrite(t, path, o)
	if err := install(path, p.Surface, false); err != nil {
		t.Fatal(err)
	}
	p.State = stateUpgrade
	p.CurrentSHA = digest(old)
	if err := restoreUpdate(path, p); err != nil {
		t.Fatal(err)
	}
	assertFile(t, path, o)
}

func TestRejectLinkAndIncorrectBackupInput(t *testing.T) {
	o, old, _, p := updateFixture()
	dir := t.TempDir()
	real := filepath.Join(dir, "real.exe")
	path := filepath.Join(dir, "game.exe")
	mustWrite(t, real, o)
	if err := os.Symlink(real, path); err != nil {
		t.Skip(err)
	}
	if _, err := applyUpdate(path, p); err == nil {
		t.Fatal("accepted symlink")
	}
	assertFile(t, real, o)
	if err := backup(real, old, p.Full); err == nil {
		t.Fatal("accepted patched bytes as original backup")
	}
}

func actualExecutable(t *testing.T) []byte {
	t.Helper()
	path := os.Getenv("LU_TEST_EXECUTABLE")
	if path == "" {
		t.Skip("set LU_TEST_EXECUTABLE to the reference binary")
	}
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

func TestActualVinylReaderAndPatchStates(t *testing.T) {
	b := actualExecutable(t)
	for _, variation := range []bool{false, true} {
		t.Run(map[bool]string{false: "exact", true: "unrelated-change"}[variation], func(t *testing.T) {
			x := b
			if variation {
				x = append(bytes.Clone(b), []byte("unrelated trailer preserved")...)
			}
			r, err := inspectUpdate(x, nil)
			if err != nil {
				t.Fatal(err)
			}
			if r.State != stateOriginal {
				t.Fatal(r.State)
			}
			if len(r.Full.Edits) != 7 || r.Upgrade.Edits[0].Offset != 0x48ff355 {
				t.Fatal("unexpected edit plan")
			}
			old, err := transform(x, r.Surface)
			if err != nil {
				t.Fatal(err)
			}
			up, err := inspectUpdate(old, nil)
			if err != nil || up.State != stateUpgrade {
				t.Fatalf("upgrade recognition %v %v", up.State, err)
			}
			latest, err := transform(old, up.Upgrade)
			if err != nil {
				t.Fatal(err)
			}
			fresh, err := transform(x, r.Full)
			if err != nil || !bytes.Equal(latest, fresh) {
				t.Fatalf("fresh/upgrade differ: %v", err)
			}
			current, err := inspectUpdate(latest, nil)
			if err != nil || current.State != stateCurrent {
				t.Fatalf("repeat recognition %v %v", current.State, err)
			}
			changed := 0
			for i := range x {
				if x[i] != latest[i] {
					changed++
				}
			}
			if changed != 24 {
				t.Fatalf("changed %d bytes, expected 24", changed)
			}
			if current.Full.Original != digest(x) {
				t.Fatal("original hash was lost")
			}
			// Mutate just the reader: an incomplete installation must not be repaired blindly.
			partial := bytes.Clone(x)
			copy(partial[r.Upgrade.Edits[0].Offset:], r.Upgrade.Edits[0].After)
			if _, err := inspectUpdate(partial, nil); err == nil {
				t.Fatal("accepted group-only partial patch")
			}
		})
	}
}

func TestActualReaderRejectsChangedAndAmbiguousCode(t *testing.T) {
	b := actualExecutable(t)
	for _, mode := range []string{"changed-body", "partial-immediate", "duplicate", "truncated", "wrong-boundary"} {
		t.Run(mode, func(t *testing.T) {
			x := bytes.Clone(b)
			switch mode {
			case "changed-body":
				x[0x48ff354+15] ^= 1
			case "partial-immediate":
				x[0x48ff355] = 0x30
			case "duplicate":
				copy(x[0x5000000:], x[0x48ff1a0:0x48ff922])
			case "truncated":
				x = x[:0x48ff360]
			case "wrong-boundary":
				// Follow the active directory; prepared EXEs may keep a second,
				// inactive copy of the runtime entries in the original .pdata.
				f, err := pe.NewFile(bytes.NewReader(x))
				if err != nil {
					t.Fatal(err)
				}
				d := f.OptionalHeader.(*pe.OptionalHeader64).DataDirectory[3]
				changed := false
				for _, s := range f.Sections {
					if uint64(d.VirtualAddress) >= uint64(s.VirtualAddress) && uint64(d.VirtualAddress)+uint64(d.Size) <= uint64(s.VirtualAddress)+uint64(s.Size) {
						base := int(s.Offset) + int(d.VirtualAddress-s.VirtualAddress)
						at := bytes.Index(x[base:base+int(d.Size)], unhex("a0fb8f0422039004"))
						if at < 0 {
							t.Fatal("runtime entry missing")
						}
						x[base+at] ^= 1
						changed = true
					}
				}
				f.Close()
				if !changed {
					t.Fatal("exception directory missing")
				}
			}
			if _, err := detectVinylReader(x); err == nil {
				t.Fatalf("accepted %s", mode)
			}
		})
	}
}

func TestActualExecutableUpgradeAndRestore(t *testing.T) {
	b := actualExecutable(t)
	path := filepath.Join(t.TempDir(), "forzahorizon6.exe")
	p, err := inspectUpdate(b, nil)
	if err != nil {
		t.Fatal(err)
	}
	mustWrite(t, path, b)
	if err = install(path, p.Surface, false); err != nil {
		t.Fatal(err)
	}
	older, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	upgrade, err := inspectUpdate(older, nil)
	if err != nil {
		t.Fatal(err)
	}
	if changed, e := applyUpdate(path, upgrade); e != nil || !changed {
		t.Fatalf("real upgrade %v %v", changed, e)
	}
	latest, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	changed := 0
	for i := range older {
		if older[i] != latest[i] {
			changed++
		}
	}
	if changed != 2 {
		t.Fatalf("upgrade altered %d bytes rather than 2", changed)
	}
	assertFile(t, buildBackupPath(path, p.Full), b)
	assertFile(t, buildBackupPath(path, p.Upgrade), older)
	current, err := inspectUpdate(latest, nil)
	if err != nil {
		t.Fatal(err)
	}
	if changed, e := applyUpdate(path, current); e != nil || changed {
		t.Fatalf("real repeat %v %v", changed, e)
	}
	if err = restoreUpdate(path, current); err != nil {
		t.Fatal(err)
	}
	assertFile(t, path, b)
	t.Logf("Full patched SHA-256: %s; upgrade changed 2 bytes; full restore matches original", current.Full.Patched)
}

func TestCommitRejectsChangedTarget(t *testing.T) {
	o, old, latest, _ := updateFixture()
	dir := t.TempDir()
	path := filepath.Join(dir, "game.exe")
	mustWrite(t, path, old)
	if err := commitVerified(path, digest(o), latest); err == nil {
		t.Fatal("replaced a target changed during preparation")
	}
	assertFile(t, path, old)
	pending, err := filepath.Glob(filepath.Join(dir, ".lu-layers-pending-*.exe"))
	if err != nil || len(pending) > 0 {
		t.Fatal("pending file was not cleaned up")
	}
}

func TestReleaseDecalCapAndBeta5MigrationPlan(t *testing.T) {
	if vinylOriginalLimit != 3000 || vinylReleaseLimit != 6500 || vinylBeta5Limit != 30000 {
		t.Fatalf("unexpected decal limits: stock=%d release=%d beta5=%d", vinylOriginalLimit, vinylReleaseLimit, vinylBeta5Limit)
	}
	stable := vinylEdit(12, vinylOriginalLimit, vinylReleaseLimit)
	if !bytes.Equal(stable.Before, []byte{0xb8, 0x0b, 0x00, 0x00}) {
		t.Fatalf("unexpected stock immediate: %x", stable.Before)
	}
	if !bytes.Equal(stable.After, []byte{0x64, 0x19, 0x00, 0x00}) {
		t.Fatalf("unexpected 6500 immediate: %x", stable.After)
	}

	original := []byte("HEAD-OLD-GRP3-TAIL")
	beta5 := []byte("HEAD-NEW-GRPB-TAIL")
	stableBytes := []byte("HEAD-NEW-GRPS-TAIL")
	p := updatePlan{
		State:      stateLegacyBeta5,
		CurrentSHA: digest(beta5),
		Full: profile{Original: digest(original), Patched: digest(stableBytes), Edits: []edit{
			{Offset: 5, Before: []byte("OLD"), After: []byte("NEW")},
			{Offset: 12, Before: []byte("3"), After: []byte("S")},
		}},
		LegacyBeta5: profile{Original: digest(beta5), Patched: digest(stableBytes), Edits: []edit{
			{Offset: 12, Before: []byte("B"), After: []byte("S")},
		}},
	}
	dir := t.TempDir()
	path := filepath.Join(dir, "game.exe")
	mustWrite(t, path, beta5)
	mustWrite(t, buildBackupPath(path, p.Full), original)
	changed, err := applyUpdate(path, p)
	if err != nil || !changed {
		t.Fatalf("beta5 migration failed: changed=%v err=%v", changed, err)
	}
	assertFile(t, path, stableBytes)
	assertFile(t, buildBackupPath(path, p.LegacyBeta5), beta5)

	p.State = stateCurrent
	p.CurrentSHA = digest(stableBytes)
	if err = restoreUpdate(path, p); err != nil {
		t.Fatal(err)
	}
	assertFile(t, path, original)
}
