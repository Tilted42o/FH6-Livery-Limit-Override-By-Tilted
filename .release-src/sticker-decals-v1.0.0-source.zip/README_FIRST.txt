Layer Limit Override - Sticker + Decal Edition v1.0.0
By Tilted42o
========================================================

WHAT THIS VERSION DOES

This is the separate Sticker + Decal release of Layer Limit Override.

Sticker / surface limits:
- Left / Right / Top: 30,000 layers each
- Other supported sticker surfaces: 10,000 layers each

Decal / saved vinyl-group limit:
- 6,500 direct child entries

The 6,500 decal/vinyl cap is intentionally lower than the experimental beta5
30,000 cap. It gives creators substantially more room than the stock 3,000
limit while reducing the extreme editor slowdown and very long save times seen
with much larger decals.

IMPORTANT PERFORMANCE WARNING

Decals/vinyl groups above Forza Horizon 6's original 3,000-layer limit can lower
frame rates while you are inside the livery editor and can make saving take
longer.

Based on testing so far, this appears to affect the editor only. No noticeable
performance impact has been observed after leaving the editor and returning to
normal driving/gameplay.

INSTALL

1. Extract the ENTIRE ZIP into one folder.
2. Keep every included file together.
3. Close Forza Horizon 6.
4. Run "Layer Limit Override - Sticker + Decal - By Tilted42o.exe".
5. Select your installed forzahorizon6.exe.
6. Read the confirmation screen and apply the override.

Do not pull the EXE out by itself. Keep LayerLimitOverride.profiles.json beside
the tool.

OFFLINE PATCH PREREQUISITE

If the tool displays MISSING OFFLINE PATCH, close FH6 and use the DVS FH6
Offline Patcher first:

https://github.com/DVS-code/FH6-Offline-Patcher/releases/tag/V1

After the offline patch is applied properly, run Layer Limit Override again and
select the patched forzahorizon6.exe.

Huge shoutout and credit to DVS for the FH6 Offline Patcher. DVS is a separate
project and is not bundled with Layer Limit Override.

UPGRADING FROM THE STICKER-ONLY VERSION

The tool recognizes the existing sticker-only release. Choose YES when prompted
to keep the sticker limits and add the 6,500 decal/vinyl override. The original
verified backup is retained and the previous sticker-only executable is also
kept as a recovery copy.

UPGRADING FROM BETA5

The tool recognizes the beta5 experimental 30,000 decal/vinyl cap. Choose YES
when prompted to replace that test cap with the release 6,500 cap. Your original
verified backup is retained and the beta5 executable is kept as a recovery copy.

BACKUPS / RESTORE

A verified original backup is kept beside the game executable using a
build-specific filename:

forzahorizon6.exe.lu-layers-backup-<original-build-hash>

Run the tool again and select the same executable to verify the installed state
or restore the exact verified original backup.

SAFETY

The tool fails closed. It does not modify an executable when the expected FH6
code cannot be verified, when the patch state is incomplete/ambiguous, when a
backup does not match, or when the target file changes during the operation.

A saved decal/vinyl group must still fit the remaining capacity of the surface
you are placing it on. The 6,500 decal/vinyl reader limit does not override the
surface's remaining layer capacity.
